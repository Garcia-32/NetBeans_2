/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package utp.edu.pe.polimorfismo;

import Libreria.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void moverFiguras(List<PiezaAjedrez> tablero) {
        for (PiezaAjedrez piezaAjedrez : tablero) {
            piezaAjedrez.mover();
        }
    }

    public static void imprimeTablero(TableroDeAjedrez tablero) {
        tablero.imprimirTablero();
    }

    public static void imprimeJugador(Jugador jugador) {
        jugador.imprimirJugador();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Crear jugadores
        Jugador jugadorBlanco = new Jugador("Blanco");
        Jugador jugadorNegro = new Jugador("Negro");

        // Crear tablero
        TableroDeAjedrez tablero = new TableroDeAjedrez();

        // Crear piezas y añadirlas al jugador y al tablero
        Peon peonBlanco = new Peon("Blanco", 2, 3);
        Caballo caballoNegro = new Caballo("Negro", 7, 6);
        Torre torreBlanco = new Torre("Blanco", 1, 1);

        jugadorBlanco.agregarPieza(peonBlanco);
        jugadorBlanco.agregarPieza(torreBlanco);
        jugadorNegro.agregarPieza(caballoNegro);

        tablero.agregarPieza(peonBlanco);
        tablero.agregarPieza(caballoNegro);
        tablero.agregarPieza(torreBlanco);

        boolean salir = false;
        while (!salir) {
            System.out.println("\nMENU AJEDREZ");
            System.out.println("1. Mover pieza");
            System.out.println("2. Mostrar tablero");
            System.out.println("3. Mostrar jugador Blanco");
            System.out.println("4. Mostrar jugador Negro");
            System.out.println("5. Salir");
            System.out.print("Elija una opción: ");
            int opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese tipo de pieza a mover (Peon, Caballo, Torre): ");
                    String tipoPieza = sc.next();
                    System.out.print("Ingrese fila actual: ");
                    int filaActual = sc.nextInt();
                    System.out.print("Ingrese columna actual: ");
                    int colActual = sc.nextInt();
                    System.out.print("Ingrese nueva fila: ");
                    int filaNueva = sc.nextInt();
                    System.out.print("Ingrese nueva columna: ");
                    int colNueva = sc.nextInt();

                    PiezaAjedrez piezaAMover = null;
                    for (PiezaAjedrez pieza : tablero.getPiezas()) {
                        if (pieza.getClass().getSimpleName().equalsIgnoreCase(tipoPieza) &&
                            pieza.getFila() == filaActual && pieza.getColumna() == colActual) {
                            piezaAMover = pieza;
                            break;
                        }
                    }

                    if (piezaAMover != null) {
                        tablero.moverFiguraPiezaAjedrez(piezaAMover, filaNueva, colNueva);
                    } else {
                        System.out.println("Pieza no encontrada en la posición indicada.");
                    }
                    break;

                case 2:
                    imprimeTablero(tablero);
                    break;
                case 3:
                    imprimeJugador(jugadorBlanco);
                    break;
                case 4:
                    imprimeJugador(jugadorNegro);
                    break;
                case 5:
                    salir = true;
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        }

        sc.close();
    }
}
