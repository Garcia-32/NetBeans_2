/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Libreria;

import java.util.List;
import java.util.ArrayList;

public class TableroDeAjedrez {
    private List<PiezaAjedrez> piezas;

    public TableroDeAjedrez() {
        piezas = new ArrayList<>();
    }

    public void agregarPieza(PiezaAjedrez pieza) {
        piezas.add(pieza);
    }

    public void moverFiguraPiezaAjedrez(PiezaAjedrez pieza, int filaNueva, int columnaNueva) {
        for (PiezaAjedrez p : piezas) {
            if (p.getFila() == filaNueva && p.getColumna() == columnaNueva && p != pieza) {
                System.out.println("La pieza " + pieza.getColor() + " " + pieza.getClass().getSimpleName() +
                                   " está comiendo a " + p.getColor() + " " + p.getClass().getSimpleName());
                piezas.remove(p);
                break;
            }
        }
        pieza.setPosicion(filaNueva, columnaNueva);
        System.out.println("Movimiento realizado: " + pieza.getColor() + " " + pieza.getClass().getSimpleName() +
                           " a la posición [" + filaNueva + ", " + columnaNueva + "]");
    }

    public void imprimirTablero() {
        System.out.println("Tablero completo:");
        for (PiezaAjedrez pieza : piezas) {
            System.out.println(pieza.getColor() + " " + pieza.getClass().getSimpleName() + 
                               " en posición Fila:" + pieza.getFila() + " Columna:" + pieza.getColumna());
        }
    }

    public List<PiezaAjedrez> getPiezas() {
        return piezas;
    }
}
