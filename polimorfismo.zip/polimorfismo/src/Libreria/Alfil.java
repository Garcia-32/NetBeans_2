/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Libreria;

public class Alfil extends PiezaAjedrez {

    public Alfil(String color, int fila, int columna) {
        super(color, fila, columna);
    }

    @Override
    public String toString() {
        return "Alfil " + super.toString();
    }

    @Override
    public void mover() {
        System.out.println("Alfil " + getColor() + " Moviendo");
    }

    @Override
    public void comer(PiezaAjedrez pieza) {
        System.out.println("Alfil " + getColor() + " COMIENDO " + pieza);
    }
}

