/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Libreria;

public abstract class PiezaAjedrez {
    private String color;
    private int fila;
    private int columna;

    public PiezaAjedrez(String color, int fila, int columna) {
        this.color = color;
        this.fila = fila;
        this.columna = columna;
    }

    public String getColor() { return color; }
    public int getFila() { return fila; }
    public int getColumna() { return columna; }

    public void setPosicion(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }

    @Override
    public String toString() {
        return "Pieza color: " + color + ", fila: " + fila + ", columna: " + columna;
    }

    public abstract void mover();
    public abstract void comer(PiezaAjedrez pieza);
}
