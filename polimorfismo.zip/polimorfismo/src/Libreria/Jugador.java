/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Libreria;

import java.util.List;
import java.util.ArrayList;

public class Jugador {
    private String color;
    private List<PiezaAjedrez> piezas;

    public Jugador(String color) {
        this.color = color;
        piezas = new ArrayList<>();
    }

    public String getColor() {
        return color;
    }

    public void agregarPieza(PiezaAjedrez pieza) {
        piezas.add(pieza);
    }

    public void imprimirJugador() {
        System.out.println("Jugador de color: " + color);
        for (PiezaAjedrez pieza : piezas) {
            System.out.println(pieza + " en posición Fila:" + pieza.getFila() + " Columna:" + pieza.getColumna());
        }
    }

    public List<PiezaAjedrez> getPiezas() {
        return piezas;
    }

    public void removerPieza(PiezaAjedrez pieza) {
        piezas.remove(pieza);
    }
}
