/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Libreria;

public class Peon extends PiezaAjedrez {

    public Peon(String color, int fila, int columna) {
        super(color, fila, columna);
    }

    @Override
    public String toString() {
        return "Peon " + super.toString();
    }

    @Override
    public void mover() {
        System.out.println("Peon " + getColor() + " Moviendo");
    }

    @Override
    public void comer(PiezaAjedrez pieza) {
        System.out.println("Peon " + getColor() + " COMIENDO " + pieza);
    }
}
